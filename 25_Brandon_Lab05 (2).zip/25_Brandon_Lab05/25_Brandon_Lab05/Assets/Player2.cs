﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player2 : MonoBehaviour
{
    public float speed;
    public Rigidbody playerRigidbody;
    public Text scoreText; // Reference to the UI Text component
    public float timeLimit = 25f; // Set the time limit in seconds
    private float currentTime;
    public Text timerText; // Reference to the UI Text component for displaying the timer

    private int score = 0;

    void Start()
    {
        currentTime = timeLimit;
        UpdateTimerText();
        StartCoroutine(Countdown());
    }

    void FixedUpdate()
    {
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveHorizontal, 0, MoveVertical);
        transform.Translate(movement * Time.fixedDeltaTime * speed);
    }

    void OnTriggerEnter(Collider other)
    {
        // Check if the colliding object is a coin
        if (other.CompareTag("Coin"))
        {
            // Increment the score
            score++;
            Destroy(other.gameObject);
            scoreText.text = "Coins Collected: " + score.ToString();
        }

        if (score == 6)
        {
            // Check if the timer script is not null
            SceneManager.LoadScene("Game Win 2");
        }

        if (other.CompareTag("Hazard"))
        {
            // Handle hazard collision (e.g., load lose scene)
            SceneManager.LoadScene("Game Lose");
        }
    }

    IEnumerator Countdown()
    {
        while (currentTime > 0)
        {
            yield return new WaitForSeconds(1f);
            currentTime--;
            UpdateTimerText();
        }

        // Handle timeout (e.g., load lose scene)
        SceneManager.LoadScene("Game Over");
    }

    void UpdateTimerText()
    {
        if (timerText != null)
        {
            timerText.text = "Time: " + currentTime.ToString("F0");
        }
    }
}