﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    public float rotationSpeed = 100f; // Adjust this value to control the rotation speed

    void Update()
    {
        // Rotate the coin around its up axis (Y-axis) based on the rotationSpeed
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
    }
}
