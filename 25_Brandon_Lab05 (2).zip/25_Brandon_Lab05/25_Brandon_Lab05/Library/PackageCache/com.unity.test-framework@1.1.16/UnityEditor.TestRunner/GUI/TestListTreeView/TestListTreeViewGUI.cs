using UnityEditor.IMGUI.Controls;

namespace UnityEditor.TestTools.TestRunner.GUI
{
    internal class TestListTreeViewGUI : TreeViewGUI
    {
        public TestListTreeViewGUI(TreeViewController testListTree) : base(testListTree)
        {
        }
    }
}
