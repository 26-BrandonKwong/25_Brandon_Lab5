﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float speed;
    public Rigidbody playerRigidbody;
    public Text scoreText; // Reference to the UI Text component

    private int score = 0;

    void Start()
    {
    }

    void Update()
    {
        // You can add any additional update logic here if needed
    }

    void FixedUpdate()
    {
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveHorizontal, 0, MoveVertical);
        transform.Translate(movement * Time.deltaTime * speed);
    }

    void OnTriggerEnter(Collider other)
    {
        // Check if the colliding object is a coin
        if (other.CompareTag("Coin"))
        {
            // Increment the score
            score++;
            Destroy(other.gameObject);
            scoreText.text = "Coins Collected: " + score.ToString();
        }
        if (score == 4)
        {
            SceneManager.LoadScene("Game Win");
        }
        if (other.CompareTag("Hazard"))
        {
            SceneManager.LoadScene("Game Lose");
        }
    }
}
