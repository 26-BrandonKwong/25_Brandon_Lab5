﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Restart1 : MonoBehaviour
{
    public void Restart()
    {
        SceneManager.LoadScene("GamePlay_Level1");
    } 
}
